module.exports = Object.freeze({
    COORDINATOR: 'COORDINATOR',
    VOLUNTEER:   'VOLUNTEER',
    LEGAL:       'LEGAL',
});